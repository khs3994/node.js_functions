//watch메서드: 파일/폴더의 변경을 감시할 수 있음

const fs = require('fs');

fs.watch('./19-16-2.target.txt', (eventType, filename) => {
    console.log(eventType,filename);
});

//target.txt의 내용 변경시 change이벤트가 콘솔창에서 실행
//파일명 변경 또는 삭제 후, rename이벤트 발생 rename이벤트 발생후 더이상 watch가 수행되지 않음