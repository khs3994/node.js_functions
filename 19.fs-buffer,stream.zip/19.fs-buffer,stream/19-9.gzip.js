//파일을 읽은후 gzip방식으로 압축하는 코드
const zlib = require('zlib');
const fs = require('fs');

const readStream = fs.createReadStream('./19-6-1.readme4.txt');
const zlibStream = zlib.createGzip();
const writeStream = fs.createWriteStream('./19-6-2.readme4.txt.gz');
readStream.pipe(zlibStream).pipe(writeStream);