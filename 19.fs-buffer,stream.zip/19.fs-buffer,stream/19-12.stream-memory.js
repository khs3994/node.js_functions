//엄청 큰파일을 스트림해서 작게 쪼개는 코드

const fs = require('fs');

console.log('before: ',process.memoryUsage().rss);

const readStream = fs.createReadStream('./19-10-1.big.txt');
const writeStream = fs.createWriteStream('./19-10-3.big3.txt');

readStream.pipe(writeStream);
readStream.on('end', () => {
    console.log('stream: ', process.memoryUsage().rss);
});

//290562048 >(스트림 후)> 26357760
//동영상 같은 큰파일들을 전송 할때 사용