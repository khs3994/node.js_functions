const fs = require('fs');

console.log('before: ', process.memoryUsage().rss);

const data1 = fs.readFileSync('./19-10-1.big.txt');
fs.writeFileSync('./19-10-2.big2.txt',data1);
console.log('buffer: ',process.memoryUsage().rss);