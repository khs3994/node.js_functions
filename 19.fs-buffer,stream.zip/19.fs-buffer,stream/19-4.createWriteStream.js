const fs = require('fs');

const writeStream = fs.createWriteStream('./19-5.writeme2.txt');//여기서 쓰기 스트림을 만듬, 첫번째 인수는 출력할 파일명이고, 두번째는 옵션인데 여기서는 쓰지 않는다.
writeStream.on('finish', () => { //파일쓰기가 종료되면 콜백함수 호출
    console.log('파일 쓰기 완료');
});
//write stream에서 제공하는 write메서드로 넣을 데이터를 씀
//다 쓰면 end로 종료를 알림 -> 이때 finsh이벤트 발생
writeStream.write('이 글을 씁니다.\n');
writeStream.write('한 번 더 씁니다.');
writeStream.end();