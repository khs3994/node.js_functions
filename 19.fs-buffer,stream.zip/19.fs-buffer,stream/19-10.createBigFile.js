const fs = require('fs');
const file = fs.createWriteStream('./19-10-1.big.txt');

for(let i = 0; i <= 10000000; i++) {
    file.write('짱짱큰 파일 만들기\n');
}
file.end();