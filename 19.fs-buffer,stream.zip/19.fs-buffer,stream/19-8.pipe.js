const fs = require('fs');

const readStream = fs.createReadStream('19-6.readme4.txt');
const  writeStream = fs.createWriteStream('19-7.writeme3.txt');
readStream.pipe(writeStream);