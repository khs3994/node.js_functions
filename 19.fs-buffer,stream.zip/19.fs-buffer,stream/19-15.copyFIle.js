//파일 복사

const fs = require('fs').promises;

fs.copyFile('19-6-1.readme4.txt', '19-15-1.writeme4.txt')
    .then(() => {
        console.log('복사 완료');
    })
    .catch((error) => {
        console.error(error);
    });