const fs = require('fs');

const readStream = fs.createReadStream('./19-2.readme3.txt', {highWaterMark: 16});//여기서 읽기 스트림을 만듬,첫번쨰 인수로 파일경로,두번째는 옵션객체
const data = [];

readStream.on('data', (chunk) =>{
    data.push(chunk);
    console.log('data :',chunk,chunk.length);
});
readStream.on('end', ()=>{
    console.log('end :',Buffer.concat(data).toString());
});

readStream.on('error', (err) => {
    console.log('error :', err);
});